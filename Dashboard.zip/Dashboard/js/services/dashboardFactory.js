(function () {
    angular.module('dashboard')
        .factory("dashboardFactory", function ($http, $q) {
            return {
                getUserDetails: function () {
                    var deferred = $q.defer();
                    $http.get('./data/data.json').success(function (data, status, headers, config) {
                        deferred.resolve(data, status, headers, config);
                    }).error(function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config)
                    });
                    return deferred.promise;
                },
                getVideoDetails: function () {
                    var deferred = $q.defer();
                    var self = this;
                    $http.get('./data/videoDashboardData.json').success(function (data, status, headers, config) {
                        self.top4Videos = data.top4Videos;
                        self.gallaryVideos = data.gallaryVideos;
                        deferred.resolve(data, status, headers, config);
                    }).error(function (data, status, headers, config) {
                        deferred.reject(data, status, headers, config)
                    });
                    return deferred.promise;
                },
                top4Videos:[],
                gallaryVideos:[]

            }
        });
})();